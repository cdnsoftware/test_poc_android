package com.clienttask.cdnfly

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CDNflyApplication : Application() {

    override fun onCreate() {
        super.onCreate()
    }
}

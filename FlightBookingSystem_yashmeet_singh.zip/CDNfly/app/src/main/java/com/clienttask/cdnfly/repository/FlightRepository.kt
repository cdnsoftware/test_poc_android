package com.clienttask.cdnfly.repository
import com.clienttask.cdnfly.communicator.ApiService
import com.clienttask.cdnfly.models.request.SearchFlightRequest
import com.clienttask.cdnfly.models.response.ModelFlightData.FlightData
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject

class FlightRepository @Inject constructor(private val apiService: ApiService) {


    suspend fun fetchFlightOptions(from: String, to: String): FlightData {
        val flightRequest = SearchFlightRequest(from, to)


        // Call the API and handle the response
        return try {
            val response = apiService.searchFlights()

            if (response.isSuccessful) {
                response.body() !! // Return an empty list if body is null
            } else {
                throw Exception("Error: ${response.message()}") // Handle API error
            }
        } catch (e: HttpException) {
            // Handle HTTP-related errors
            throw Exception("HTTP Error: ${e.code()} - ${e.message()}")
        } catch (e: IOException) {
            // Handle network errors (e.g., no internet connection)
            throw Exception("Network Error: ${e.message}")
        } catch (e: Exception) {
            // Handle any other unexpected errors
            throw Exception("An unexpected error occurred: ${e.message}")
        }
    }
}

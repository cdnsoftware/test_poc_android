package com.clienttask.cdnfly.models.request

import java.sql.Struct

data class SearchFlightRequest(
    val arrival:String,
    val departure:String
)

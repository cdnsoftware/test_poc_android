package com.clienttask.cdnfly.view.activity.searchflights

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.clienttask.cdnfly.models.response.ModelFlightData.FlightData
import com.clienttask.cdnfly.repository.FlightRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class SearchFlightViewModel @Inject constructor(
    private val flightRepository: FlightRepository
) : ViewModel() {
    val TAG="SearchViewModel"
    // LiveData for holding flight results
    private val _flights = MutableLiveData<FlightData>()
    val flights: LiveData<FlightData> get() = _flights

    // LiveData for handling errors
    private val _error = MutableLiveData<String>()
    val error: LiveData<String> get() = _error

    // Method to search for flights
    fun fetchFlightOptions(from: String, to: String) {
        viewModelScope.launch {
            try {

                val flightList = flightRepository.fetchFlightOptions(from, to)
                if(flightList!=null){
                _flights.value = flightRepository.fetchFlightOptions(from, to)}

                Log.d(TAG, "searchFlights: ")
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }
}

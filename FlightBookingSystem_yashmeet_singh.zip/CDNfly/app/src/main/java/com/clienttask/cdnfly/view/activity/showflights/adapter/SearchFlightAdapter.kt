package com.clienttask.cdnfly.view.activity.showflights

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.clienttask.cdnfly.R
import com.clienttask.cdnfly.models.response.ModelFlightData.Flight
import com.clienttask.cdnfly.view.activity.showavailableseats.ShowAvailableSeats

class FlightAdapter(private var flightList:List<Flight>, val from:String, val to:String, val passengerCount:String, val context:Context) :
    RecyclerView.Adapter<FlightAdapter.FlightViewHolder>() {
        //view holder class
    class FlightViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val flightNumber: TextView = itemView.findViewById(R.id.flightNumber)
        val departureTime: TextView = itemView.findViewById(R.id.departureTime)
        val price: TextView = itemView.findViewById(R.id.price)
        val from:TextView=itemView.findViewById(R.id.from)
        val to:TextView=itemView.findViewById(R.id.to)
        val mainView: ConstraintLayout = itemView.findViewById(R.id.mainLayout)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FlightViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_flight, parent, false)
        return FlightViewHolder(view)
    }

    override fun onBindViewHolder(holder: FlightViewHolder, position: Int) {
        val flight = flightList[position]
        holder.flightNumber.text = flight.flightNumber
        holder.departureTime.text = flight.departureTime
        holder.price.text = flight.price.toString()
        holder.from.text=from
        holder.to.text=to
        holder.mainView.setOnClickListener{
            val intent = Intent(context, ShowAvailableSeats::class.java).apply {
                putExtra("FLIGHT_NUMBER", flight.flightNumber)
                putExtra("PRICE", flight.price.toString())
                putExtra("passenger_count",passengerCount)
                            }
            context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return flightList.size
    }
    @SuppressLint("NotifyDataSetChanged")
    fun updateList(newList: List<Flight>) {
        flightList = newList
        notifyDataSetChanged() // Refresh the RecyclerView
    }
}

package com.clienttask.cdnfly.view.activity.splashscreen


import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.clienttask.cdnfly.R
import com.clienttask.cdnfly.databinding.ActivitySplashScreenBinding
import com.clienttask.cdnfly.view.activity.searchflights.SearchFlights


class SplashScreen : AppCompatActivity() {
    private lateinit var binding: ActivitySplashScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        startPlaneAnimation()
    }

    // Handling plane-icon animation
    private fun startPlaneAnimation() {
        val animation: Animation = AnimationUtils.loadAnimation(this, R.anim.plane_animation)
        binding.plane.startAnimation(animation)

        animation.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationStart(animation: Animation?) {
                // You can add any action to be performed when animation starts
            }

            override fun onAnimationEnd(animation: Animation?) {
                binding.plane.visibility = View.GONE

                // Change to the intended main activity here
                val intent = Intent(this@SplashScreen, SearchFlights::class.java) // Use your main activity
                val anim = ActivityOptions.makeCustomAnimation(
                    applicationContext,
                    R.anim.slide_in,
                    R.anim.slide_out
                ).toBundle()
                startActivity(intent, anim)

                finishAffinity() // Close the splash screen activity
            }

            override fun onAnimationRepeat(animation: Animation?) {
                // You can add any action to be performed when animation repeats
            }
        })
    }
}

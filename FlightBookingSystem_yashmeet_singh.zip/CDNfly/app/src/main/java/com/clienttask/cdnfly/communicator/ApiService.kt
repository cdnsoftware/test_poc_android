package com.clienttask.cdnfly.communicator

import com.clienttask.cdnfly.constant.ApiConstants
import com.clienttask.cdnfly.models.request.SearchFlightRequest
import com.clienttask.cdnfly.models.response.ModelFlightData.FlightData
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {

    @POST(ApiConstants.FLIGHT_SEARCH_ENDPOINT)
    suspend fun searchFlights(): Response<FlightData>
}

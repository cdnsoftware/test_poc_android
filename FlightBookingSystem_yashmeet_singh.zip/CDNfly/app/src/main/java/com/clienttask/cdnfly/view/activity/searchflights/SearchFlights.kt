package com.clienttask.cdnfly.view.activity.searchflights

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.clienttask.cdnfly.R
import com.clienttask.cdnfly.databinding.ActivitySearchFlightsBinding
import com.clienttask.cdnfly.view.activity.BaseActivity
import com.clienttask.cdnfly.view.activity.showflights.ShowFlights
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@AndroidEntryPoint
class SearchFlights : BaseActivity() {

    private lateinit var binding: ActivitySearchFlightsBinding
    private val viewModel: SearchFlightViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySearchFlightsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.title.text = getString(R.string.search_flights)
        binding.toolbar.backButton.visibility = View.GONE

        binding.searchButton.setOnClickListener {
            validateInputs()
        }

        // Observe flight results
        viewModel.flights.observe(this, Observer { flights ->
            binding.loadingIndicator.visibility = View.GONE
            if (flights.flights.isNotEmpty()) {
                // Start ShowFlights Activity
                val intent = Intent(this, ShowFlights::class.java).apply {
                    putExtra("from", binding.departureLocationEditText.text.toString())
                    putExtra("to", binding.arrivalLocationEditText.text.toString())
                    putExtra("passenger_count",binding.passengerCount.text.toString())
                }
                binding.searchButton.isEnabled=true
                startActivity(intent)

            } else {
                showToast("No flights available")
                binding.searchButton.isEnabled=true
            }
        })

        // Observe error messages
        viewModel.error.observe(this, Observer { errorMessage ->
            binding.loadingIndicator.visibility = View.GONE
            showToast(errorMessage)
            binding.searchButton.isEnabled=true
        })
    }

    //Validating input fields
    private fun validateInputs() {
        val fromInput = binding.departureLocationEditText.text.toString().trim()
        val toInput = binding.arrivalLocationEditText.text.toString().trim()
        val passengerCount = binding.passengerCount.text.toString().trim()

        when {
            fromInput.isEmpty() -> {
                showToast("Please enter a departure location")
                return
            }
            toInput.isEmpty() -> {
                showToast("Please enter a destination")
                return
            }
            passengerCount.isEmpty() -> {
                showToast("Please enter the number of passengers")
                return
            }
            passengerCount.toIntOrNull() == null || passengerCount.toInt() < 1  -> {
                showToast("You can select minimum 1 or maximum 4 passengers only")
                return
            }
        }

        // Perform search through ViewModel with loading indicator
        binding.loadingIndicator.visibility = View.VISIBLE
        binding.searchButton.isEnabled=false
        // Perform search through ViewModel with loading indicator
        binding.loadingIndicator.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            viewModel.fetchFlightOptions(fromInput, toInput)
        }
    }
}

package com.clienttask.cdnfly.view.activity.showflights

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.clienttask.cdnfly.R
import com.clienttask.cdnfly.databinding.ActivityShowFlightsBinding
import com.clienttask.cdnfly.view.activity.searchflights.SearchFlightViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ShowFlights : AppCompatActivity() {
    val TAG="ShowFlights"
    private lateinit var binding: ActivityShowFlightsBinding
    private val viewModel: SearchFlightViewModel by viewModels()
    private lateinit var flightAdapter: FlightAdapter
    private lateinit var from: String
    private lateinit var to: String
    private lateinit var countPassenger:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShowFlightsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.backButton.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
        binding.toolbar.title.text = getString(R.string.available_flights)

        from = intent.getStringExtra("from") ?: ""
        to = intent.getStringExtra("to") ?: ""
        countPassenger = intent.getStringExtra("passenger_count") ?: ""

        setupRecyclerView()
        observeFlights()

        // Trigger flight search
        viewModel.fetchFlightOptions(from, to)
        val dataList = viewModel.flights.value
        Log.d(TAG, "onCreate: $dataList")
        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filter(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })


    }
    // Filter the flight list based on the search query
    private fun filter(text: String) {
        val currentList = viewModel.flights.value!!.flights
        val filteredList = currentList.filter { it.flightNumber.contains(text, ignoreCase = true) && it.price < 500 }

        // Update the adapter with the filtered list
        flightAdapter.updateList(filteredList)
    }

    //Setting up recycler view
    private fun setupRecyclerView() {
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        flightAdapter = FlightAdapter(emptyList(), from, to, countPassenger,this)
        binding.recyclerView.adapter = flightAdapter
    }

    //observing flights data
    private fun observeFlights() {
        viewModel.flights.observe(this) { flightData ->
            flightData?.flights?.let { flights ->
                val filteredFlights = flights.filter { flight ->
                    flight.price <= 500 // Assuming price is a property of flight
                }

                if (filteredFlights.isNotEmpty()) {
                    flightAdapter = FlightAdapter(filteredFlights, from, to,countPassenger, this)
                    binding.recyclerView.adapter = flightAdapter
                } else {

                    Log.d("ShowFlights", "No flights available under 500")
                }
            }
        }

        viewModel.error.observe(this) { errorMessage ->
            Log.e("ShowFlights", "Error: $errorMessage")
        }
    }
}

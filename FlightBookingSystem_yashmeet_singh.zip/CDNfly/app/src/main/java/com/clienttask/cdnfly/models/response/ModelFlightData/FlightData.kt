package com.clienttask.cdnfly.models.response.ModelFlightData

data class FlightData(
    val flights: List<Flight>,
    val responseMessage: String
)
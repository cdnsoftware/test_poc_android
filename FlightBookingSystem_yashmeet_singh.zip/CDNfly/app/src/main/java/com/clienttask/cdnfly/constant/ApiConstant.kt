package com.clienttask.cdnfly.constant


object ApiConstants {
    const val BASE_URL = "https://run.mocky.io/v3/"
    const val FLIGHT_SEARCH_ENDPOINT = "f3cea6fb-c348-4651-a882-3443d555ccd8"

}

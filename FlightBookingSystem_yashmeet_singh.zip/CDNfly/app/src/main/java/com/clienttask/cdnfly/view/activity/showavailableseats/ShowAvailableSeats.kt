
package com.clienttask.cdnfly.view.activity.showavailableseats

import android.content.Intent
import android.os.Bundle
import android.widget.Toast

import androidx.lifecycle.lifecycleScope
import com.clienttask.cdnfly.R
import com.clienttask.cdnfly.databinding.ActivityShowAvailableSeatsBinding
import com.clienttask.cdnfly.view.activity.BaseActivity
import com.clienttask.cdnfly.view.activity.searchflights.SearchFlights
import dev.jahidhasanco.seatbookview.SeatBookView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ShowAvailableSeats : BaseActivity() {

    private lateinit var binding: ActivityShowAvailableSeatsBinding
    private lateinit var seatBookView: SeatBookView

    // Seat layout string
    private val seats = (
            "/U___S" +
                    "/_____" +
                    "/AA_AA" +
                    "/UA_AR" +
                    "/AA_AA" +
                    "/RU_AA" +
                    "/AA_AR" +
                    "/AU_AA" +
                    "/AA_AA" +
                    "/AAAAA"
            )

    // Custom titles for the seats
    private val title = listOf(
        "/", "I1", "", "", "", "E5",
        "/", "", "", "", "", "",
        "/", "A1", "A2", "", "A3", "A4",
        "/", "B1", "B2", "", "B3", "B4",
        "/", "C1", "C2", "", "C3", "C4",
        "/", "D1", "D2", "", "D3", "D4",
        "/", "E1", "E2", "", "E3", "E4",
        "/", "F1", "F2", "", "F3", "F4",
        "/", "G1", "G2", "", "G3", "G4",
        "/", "H1", "H2", "H3", "H4", "H5"
    )

    // Variables to hold flight information
    private lateinit var flightNumber: String
    private lateinit var price: String
    private var passengerCount: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShowAvailableSeatsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        retrieveIntentData()
        initializeSeatBookView()
        CoroutineScope(Dispatchers.Main).launch{  fetchSeatsAvailability(flightNumber)}
        binding.confirmButton.setOnClickListener {
            val bookedSeats = seatBookView.getSelectedIdList().size
            if (bookedSeats == 0) {
                showToast("Select seats to continue")
            } else {
                Toast.makeText(this, "Congratulations, your seats are booked", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, SearchFlights::class.java))
                finishAffinity()
            }
        }
    }

    // Setting up toolbar
    private fun setupToolbar() {
        binding.toolbar.backButton.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    // Retrieving intent data
    private fun retrieveIntentData() {
        flightNumber = intent.getStringExtra("FLIGHT_NUMBER").toString()
        price = intent.getStringExtra("PRICE").toString()
        passengerCount = intent.getStringExtra("passenger_count")?.toInt() ?: 0
    }

    // Initializing seat book view
    private fun initializeSeatBookView() {
        seatBookView = binding.layoutSeat
        seatBookView.setSeatsLayoutString(seats)
            .isCustomTitle(true)
            .setCustomTitle(title)
            .setSeatLayoutPadding(2)
            .setSeatSizeBySeatsColumnAndLayoutWidth(5, -1)

        seatBookView.setSelectSeatLimit(passengerCount)
        seatBookView.show()
    }

    // Fetch seat availability (asynchronously)
    private suspend fun  fetchSeatsAvailability(flightId: String) {
        // Launch a coroutine to handle fetching in the background
        lifecycleScope.launch {
            // Simulate a network delay
            withContext(Dispatchers.Main) {
                // Simulate fetching data (replace with actual API call)
                delay(2000)

            }
            // Handle UI updates after fetching data (if needed)
          /*  Toast.makeText(this@ShowAvailableSeats, "Seat availability fetched", Toast.LENGTH_SHORT).show()*/
        }
    }
}

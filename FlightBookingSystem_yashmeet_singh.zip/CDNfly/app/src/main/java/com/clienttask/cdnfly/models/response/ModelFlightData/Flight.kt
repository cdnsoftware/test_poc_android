package com.clienttask.cdnfly.models.response.ModelFlightData

data class Flight(
    val departureTime: String,
    val flightNumber: String,
    val price: Double
)
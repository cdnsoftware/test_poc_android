package com.example.filghtbooking.apicalling

// A sealed class to handle API response with status codes
sealed class ApiResponse<T>(
    val data: T? = null,
    val message: String? = null,
    val statusCode: Int? = null
) {
    class Success<T>(data: T, statusCode: Int) : ApiResponse<T>(data = data, statusCode = statusCode)
    class Error<T>(message: String, statusCode: Int) : ApiResponse<T>(message = message, statusCode = statusCode)
}
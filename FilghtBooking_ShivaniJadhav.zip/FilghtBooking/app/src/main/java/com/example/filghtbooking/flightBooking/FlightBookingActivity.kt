package com.example.filghtbooking.flightBooking
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.EditText
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.filghtbooking.R
import com.example.filghtbooking.SeatAvabilityActivity


class FlightBookingActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FlightAdapter
    private val flightViewModel: FlightViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        val searchEditText: EditText = findViewById(R.id.searchEditText)

        // Set up the TextWatcher for search functionality
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                // Filter the list
                filter(s.toString())
            }
        })
        recyclerView.layoutManager = LinearLayoutManager(this)

        flightViewModel.fetchFlightDetails() // Fetch data from API

        flightViewModel.flightDetails.observe(this) { FilghtData ->
            val filteredList = FilghtData.flights.filter {
                it.flightNumber.contains("", ignoreCase = true) && it.price < 500
            }
            adapter = FlightAdapter(this@FlightBookingActivity, filteredList)
            recyclerView.adapter = adapter
        }
    }

    // Filter the flight list based on the search query
    private fun filter(text: String) {
        val currentList = flightViewModel.flightDetails.value?.flights ?: emptyList()
        val filteredList = currentList.filter { it.flightNumber.contains(text, ignoreCase = true) && it.price < 500 }

        // Update the adapter with the filtered list
        adapter.updateList(filteredList)
    }

    fun fetchSeatAvailability(date: String, time: String, flightNumber: String) {
        openInputDialog(flightNumber)
    }
    private fun openInputDialog(flightNumber: String) {
        // Create an EditText for user input
        val editText = EditText(this).apply {
            hint = "Enter your seat number"
            inputType = InputType.TYPE_CLASS_NUMBER // Set to number input
        }

        val alertDialog = AlertDialog.Builder(this)
            .setTitle("Seat Booking $flightNumber")
            .setMessage("Please enter your number of seats:")
            .setView(editText) // Add the EditText to the dialog
            .setPositiveButton("Yes", null) // Set null for now, we will override later
            .setNegativeButton("No") { dialog, which ->
                dialog.dismiss() // Close the dialog
            }
            .setIcon(android.R.drawable.ic_dialog_alert)
            .create()

        // Show the dialog
        alertDialog.show()

        // Override the "Yes" button to handle validation
        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            // Get the input from the EditText
            val inputValue = editText.text.toString()

            // Validate the input value
            if (inputValue.isEmpty()) {
                // Show an error message if the input is empty
                editText.error = "Seat number is required"
            } else {
                // Input is valid, dismiss the dialog and navigate to the next screen
                alertDialog.dismiss()
                fetchSeatAvailability(inputValue)
            }
        }
    }


    // Function to navigate to the next screen
    private fun fetchSeatAvailability(flightNumber: String) {
        // Start the next activity and pass the input value
        val intent = Intent(this, SeatAvabilityActivity::class.java)
        intent.putExtra("flightNumber", flightNumber)
        startActivity(intent)

    }

}
package com.example.filghtbooking.flightBooking
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.filghtbooking.R
import com.example.filghtbooking.model.Flight

class FlightAdapter(
    private val context: Context,
    var flights: List<Flight>,
) : RecyclerView.Adapter<FlightAdapter.FlightViewHolder>() {

    // ViewHolder to hold references to views in item layout
    class FlightViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val flight_name: TextView = itemView.findViewById(R.id.flight_name)
        val price_value: TextView = itemView.findViewById(R.id.price_value)
        val departureTime: TextView = itemView.findViewById(R.id.departureTime)
        val cardView: CardView = itemView.findViewById(R.id.cardView)
    }
    // Update the adapter with a new list
    fun updateList(newList: List<Flight>) {
        flights = newList
        notifyDataSetChanged() // Refresh the RecyclerView
    }
    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FlightViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.single_item_booking_list, parent, false)
        return FlightViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(holder: FlightViewHolder, position: Int) {
        holder.flight_name.text =""+flights[position].flightNumber
        holder.price_value.text =flights[position].price.toString()

        holder.departureTime.text =flights[position].departureTime.toString()
        holder.cardView.setOnClickListener {
            Handler(Looper.getMainLooper()).postDelayed({
                (context as FlightBookingActivity).fetchSeatAvailability("10:30", flights[position].departureTime, flights[position].flightNumber)
            }, 1000)
        }
    }

    override fun getItemCount(): Int {
        return flights.size
    }

}
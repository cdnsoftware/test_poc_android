package com.example.filghtbooking.apicalling
import com.example.filghtbooking.model.FilghtData
import retrofit2.http.GET


interface ApiService {
    @GET("f3cea6fb-c348-4651-a882-3443d555ccd8") // Update with your API endpoint
    suspend fun getFlightDetails(): FilghtData
}
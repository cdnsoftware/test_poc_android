package com.example.filghtbooking.flightBooking
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.filghtbooking.model.FilghtData
import kotlinx.coroutines.*

class FlightViewModel : ViewModel() {

    private val repository = FlightRepository()
    private val _flightDetails = MutableLiveData <FilghtData>()
    val flightDetails: LiveData <FilghtData> get() = _flightDetails

    fun fetchFlightDetails() {
        viewModelScope.launch {
            try {
                val flightList = repository.fetchFlightOptions()
                _flightDetails.value = flightList
            } catch (e: Exception) {
                // Handle the exception
                e.printStackTrace()
            }
        }
    }
}

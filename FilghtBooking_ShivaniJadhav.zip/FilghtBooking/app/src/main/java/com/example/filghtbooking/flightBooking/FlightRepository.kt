package com.example.filghtbooking.flightBooking

import com.example.filghtbooking.apicalling.RetrofitClient
import com.example.filghtbooking.model.FilghtData

class FlightRepository {

    private val apiService = RetrofitClient.instance

    suspend fun fetchFlightOptions(): FilghtData{
        return apiService.getFlightDetails()
    }
}

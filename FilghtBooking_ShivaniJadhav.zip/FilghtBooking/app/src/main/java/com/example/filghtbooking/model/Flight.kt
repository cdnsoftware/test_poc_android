package com.example.filghtbooking.model

data class Flight(
    val departureTime: String,
    val flightNumber: String,
    val price: Double
)
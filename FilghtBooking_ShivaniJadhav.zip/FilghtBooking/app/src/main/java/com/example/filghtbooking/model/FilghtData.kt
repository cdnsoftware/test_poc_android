package com.example.filghtbooking.model

data class FilghtData(
    val flights: List<Flight>,
    val responseMessage: String
)
package com.example.filghtbooking.apicalling
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


object RetrofitClient {
    private const val BASE_URL = "https://run.mocky.io/v3/" // Update with your API base URL


        val interceptor = HttpLoggingInterceptor()

         val client = OkHttpClient.Builder()
            .addInterceptor(interceptor) // Add your interceptor here
            .build()
    val instance: ApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client) // Set the OkHttpClient

            .addConverterFactory(GsonConverterFactory.create())
            .build()
        // Create OkHttpClient and add the interceptor
        retrofit.create(ApiService::class.java)

    }

}
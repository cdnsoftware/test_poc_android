package com.example.filghtbooking
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.filghtbooking.flightBooking.FlightBookingActivity
import dev.jahidhasanco.seatbookview.SeatBookView
import dev.jahidhasanco.seatbookview.SeatClickListener


class SeatAvabilityActivity : AppCompatActivity(){

    var travellers = "0"
    private lateinit var SeatBookView: SeatBookView
    private lateinit var back_icon: ImageView
    private lateinit var submit: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.seat_avability)
        initView()
    }

    fun initView(){
        travellers = intent.getStringExtra("flightNumber").toString()
        SeatBookView = findViewById(R.id.SeatBookView)
        back_icon = findViewById(R.id.back_icon)
        submit = findViewById(R.id.submit)
        back_icon.setOnClickListener { onBackPressed() }

        var seats = (
                "/R___R" +
                        "/_____" +
                        "/AA_AA" +
                        "/AA_AR" +
                        "/AA_AA" +
                        "/RR_AA" +
                        "/AA_AR" +
                        "/AR_AA" +
                        "/AA_AA" +
                        "/AAAAA"
                )

        var title = listOf(
            "/", "I1", "", "", "", "E5",
            "/", "", "", "", "", "",
            "/", "A1", "A2", "", "A3", "A4",
            "/", "B1", "B2", "", "B3", "B4",
            "/", "C1", "C2", "", "C3", "C4",
            "/", "D1", "D2", "", "D3", "D4",
            "/", "E1", "E2", "", "E3", "E4",
            "/", "F1", "F2", "", "F3", "F4",
            "/", "G1", "G2", "", "G3", "G4",
            "/", "H1", "H2", "H3", "H4", "H5"
        )

        SeatBookView.setSeatsLayoutString(seats)
            .isCustomTitle(true)
            .setCustomTitle(title)
            .setSeatLayoutPadding(2)
            .setSelectSeatLimit(travellers.toInt())
            .setSeatSizeBySeatsColumnAndLayoutWidth(5, -1)

        SeatBookView.setSeatClickListener(object : SeatClickListener {
            override fun onAvailableSeatClick(selectedIdList: List<Int>, view: View) {
                SeatBookView.setAvailableSeatsTextColor(ContextCompat.getColor(this@SeatAvabilityActivity, R.color.white))
            }
            override fun onBookedSeatClick(view: View) {
            }
            override fun onReservedSeatClick(view: View) {
                Toast.makeText(this@SeatAvabilityActivity, (view as TextView).text.toString() +" seat is already reserved.", Toast.LENGTH_SHORT).show()
            }
        })

        SeatBookView.show()
        submit.setOnClickListener {
            openDialog("5");
        }
        }
    private fun openDialog(flightNumber: String) {
        val alertDialog = AlertDialog.Builder(this)
            .setTitle("Seat Booking Successfully")

            .setPositiveButton("Yes") { dialog, which ->
                dialog.dismiss()
                val intent = Intent(this, FlightBookingActivity::class.java)
                startActivity(intent)
                finish()
            }
            .create()

        // Show the dialog
        alertDialog.show()
    }
}
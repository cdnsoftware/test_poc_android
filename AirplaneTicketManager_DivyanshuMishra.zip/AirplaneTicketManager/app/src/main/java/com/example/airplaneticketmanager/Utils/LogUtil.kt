package com.gsp.android.utils

import android.util.Log
import com.example.airplaneticketmanager.BuildConfig

/**
 * Created by devendrasahu
 */
object LogUtil {
    private const val LOG_LEVEL_VERBOSE = 1
    private const val LOG_LEVEL_DEBUG = 2
    private const val LOG_LEVEL_INFO = 3
    private const val LOG_LEVEL_WARN = 4
    private const val LOG_LEVEL_ERROR = 5

    /**
     * writes log level e in debug build only
     */
    fun e(tag: String, msg: String) {
        log(LOG_LEVEL_ERROR, tag, msg)
    }

    /**
     * writes log level w in debug build only
     */
    fun w(tag: String, msg: String) {
        log(LOG_LEVEL_WARN, tag, msg)
    }

    /**
     * writes log level d in debug build only
     */
    fun d(tag: String, msg: String) {
        log(LOG_LEVEL_DEBUG, tag, msg)
    }

    /**
     * writes log level i in debug build only
     */
    fun i(tag: String, msg: String) {
        log(LOG_LEVEL_INFO, tag, msg)
    }

    /**
     * writes log level v in debug build only
     */
    fun v(tag: String, msg: String) {
        log(LOG_LEVEL_VERBOSE, tag, msg)
    }

    fun printStackTrace(tag: String?, exception: Exception) {
        if (BuildConfig.DEBUG) {
            exception.printStackTrace()
        }
    }

    private fun log(level: Int, tag: String, msg: String) {
        var msg: String? = msg
        if (BuildConfig.DEBUG) {
            if (msg == null) {
                msg = ""
            }
            msg = Thread.currentThread().name + ": " + msg
            when (level) {
                LOG_LEVEL_DEBUG -> Log.d(tag, msg)
                LOG_LEVEL_ERROR -> Log.e(tag, msg)
                LOG_LEVEL_INFO -> Log.i(tag, msg)
                LOG_LEVEL_WARN -> Log.w(tag, msg)
                LOG_LEVEL_VERBOSE -> Log.v(tag, msg)
            }
        }
    }

    /**
     * prints long data like api response in multiple lines.
     *
     * @param tag
     * @param data
     */
    fun printLongData(tag: String?, data: String) {
        if (BuildConfig.DEBUG) {
            val chunkSize = 2048
            var i = 0
            while (i < data.length) {
                Log.d(tag, data.substring(i, Math.min(data.length, i + chunkSize)))
                i += chunkSize
            }
        }
    }
}

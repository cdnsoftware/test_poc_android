package com.example.airplaneticketmanager.ui.login.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.activity.viewModels
import com.example.airplaneticketmanager.BaseActivity
import com.example.airplaneticketmanager.Utils.Constants
import com.example.airplaneticketmanager.databinding.ActivityLoginBinding
import com.example.airplaneticketmanager.models.LoginRequest
import com.example.airplaneticketmanager.ui.dashboard.activity.DashboardActivity
import com.example.airplaneticketmanager.ui.login.viewModel.LoginViewModel
import com.gsp.android.utils.ProgressBarHelper
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginActivity : BaseActivity() {

    lateinit var binding: ActivityLoginBinding
    private val loginViewModel: LoginViewModel by viewModels()
    var TAG = javaClass.simpleName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initView()
        apiResponse()
    }

    fun initView() {
        binding.btnLogin.setOnClickListener {
            if (binding.etUsername.text.toString().isBlank()){
                Toast.makeText(this, "Please enter username", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            } else if (binding.etPassword.text.toString().isBlank()){
                Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            } else {
                ProgressBarHelper.show(this)

                //login api call
                val loginReq = LoginRequest(binding.etUsername.text.toString(), binding.etPassword.text.toString())
//                loginViewModel.login(loginReq)

                //below is static transaction of activity
                Handler(Looper.getMainLooper()).postDelayed({
                    ProgressBarHelper.hide()
                    val intent = Intent(this, DashboardActivity::class.java)
                    intent.putExtra(Constants.username, binding.etUsername.text.toString())
                    intent.putExtra(Constants.password, binding.etPassword.text.toString())
                    startActivity(intent)
                    finish()
                }, 1000)
            }
        }
    }

    private fun apiResponse() {
        // Observe success response
        loginViewModel.success.observe(this) { response ->
            Handler(Looper.getMainLooper()).postDelayed({
                ProgressBarHelper.hide()
            }, 2000)
            response?.let {
                // Handling success
                Log.d(TAG, it.message)
                val intent = Intent(this, DashboardActivity::class.java)
                startActivity(intent)
                finish()
            }
        }

        // Observe error response
        loginViewModel.error.observe(this) { errorMessage ->
            Handler(Looper.getMainLooper()).postDelayed({
                ProgressBarHelper.hide()
            }, 2000)
            errorMessage?.let {
                // Handling error
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        }
    }
}
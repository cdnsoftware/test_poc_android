package com.example.airplaneticketmanager.models

data class LoginResponse(
    val code : Int,
    val message : String,
    val isSuccessful : Boolean
)
package com.example.airplaneticketmanager

import androidx.appcompat.app.AppCompatActivity

open class BaseActivity : AppCompatActivity() {
}
package com.example.airplaneticketmanager.Utils

class Constants {

    companion object {
        val username = "UserName"
        val password = "Password"

        val from = "from"
        val to = "to"
        val date = "date"
        val flight_options_data = "flight_options_data"
        val travellers = "travellers"

        //api endpoints
        var LOGIN_END_POINT = "/login"
        var FETCH_FLIGHT_OPTIONS = "/fetchFlightOptions"
    }
}
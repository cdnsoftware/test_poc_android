package com.example.airplaneticketmanager.ui.dashboard.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.airplaneticketmanager.models.Flight
import com.example.airplaneticketmanager.models.FlightListResponse
import com.example.airplaneticketmanager.models.FlightOptionsRequest
import com.example.airplaneticketmanager.network.repository.FetchFlightListRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException
import java.util.concurrent.TimeoutException
import javax.inject.Inject

@HiltViewModel
class FetchFlightOptionsViewModel @Inject constructor(
    private val repository: FetchFlightListRepository
) : ViewModel() {

    // LiveData to handle success case
    private val _success = MutableLiveData<FlightListResponse?>()
    val success: LiveData<FlightListResponse?> get() = _success

    // LiveData to handle error case
    private val _error = MutableLiveData<String>()
    val error: LiveData<String> get() = _error

    fun fetchFlightOptions(requestData: FlightOptionsRequest) {
        viewModelScope.launch {
            try {
                val result = repository.fetchFlightOptions(requestData, "f3cea6fb-c348-4651-a882-3443d555ccd8")
                if (result != null) {
                    // Post success result
                    _success.postValue(result)
                } else {
                    // Post generic error message
                    _error.postValue("An unknown error occurred.")
                }
            } catch (e: IOException) {
                // Handle network-related errors (e.g., no internet connection)
                _error.postValue("Network error: Check your connection.")
            } catch (e: HttpException) {
                // Handle HTTP response errors (e.g., 4xx or 5xx responses)
                _error.postValue("Server error: ${e.code()} ${e.message()}")
            } catch (e: TimeoutException) {
                // Handle timeouts (e.g., request taking too long)
                _error.postValue("Request timeout. Please try again.")
            } catch (e: Exception) {
                // Catch any other unknown errors
                _error.postValue("Unexpected error: ${e.localizedMessage}")
            }
        }
    }
}
package com.example.airplaneticketmanager.ui.dashboard.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.airplaneticketmanager.BaseActivity
import com.example.airplaneticketmanager.R
import com.example.airplaneticketmanager.Utils.Constants
import com.example.airplaneticketmanager.databinding.ActivitySeatSelectionBinding
import dagger.hilt.android.AndroidEntryPoint
import dev.jahidhasanco.seatbookview.SeatBookView
import dev.jahidhasanco.seatbookview.SeatClickListener

@AndroidEntryPoint
class SeatSelectionActivity : BaseActivity(){

    lateinit var binding : ActivitySeatSelectionBinding
    var travellers = "0"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySeatSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initView()
    }

    fun initView(){
        travellers = intent.getStringExtra(Constants.travellers).toString()

        binding.backIcon.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        var seats = (
                "/R___R" +
                        "/_____" +
                        "/AA_AA" +
                        "/AA_AR" +
                        "/AA_AA" +
                        "/RR_AA" +
                        "/AA_AR" +
                        "/AR_AA" +
                        "/AA_AA" +
                        "/AAAAA"
                )

        var title = listOf(
            "/", "I1", "", "", "", "E5",
            "/", "", "", "", "", "",
            "/", "A1", "A2", "", "A3", "A4",
            "/", "B1", "B2", "", "B3", "B4",
            "/", "C1", "C2", "", "C3", "C4",
            "/", "D1", "D2", "", "D3", "D4",
            "/", "E1", "E2", "", "E3", "E4",
            "/", "F1", "F2", "", "F3", "F4",
            "/", "G1", "G2", "", "G3", "G4",
            "/", "H1", "H2", "H3", "H4", "H5"
        )

        binding.layoutSeat.setSeatsLayoutString(seats)
            .isCustomTitle(true)
            .setCustomTitle(title)
            .setSeatLayoutPadding(2)
            .setSelectSeatLimit(travellers.toInt())
            .setSeatSizeBySeatsColumnAndLayoutWidth(5, -1)

        binding.layoutSeat.setSeatClickListener(object : SeatClickListener {
            override fun onAvailableSeatClick(selectedIdList: List<Int>, view: View) {
                binding.layoutSeat.setAvailableSeatsTextColor(ContextCompat.getColor(this@SeatSelectionActivity, R.color.white))
            }
            override fun onBookedSeatClick(view: View) {
            }
            override fun onReservedSeatClick(view: View) {
                Toast.makeText(this@SeatSelectionActivity, (view as TextView).text.toString() +" seat is reserved.", Toast.LENGTH_SHORT).show()
            }
        })

        binding.layoutSeat.show()

        binding.btnConfirm.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                if (binding.layoutSeat.getSelectedIdList().size.toString().equals(travellers)) {
                    Toast.makeText(
                        this@SeatSelectionActivity,
                        "${travellers} Seats booked successfully",
                        Toast.LENGTH_LONG
                    ).show()
                    finishAffinity()
                    val intent = Intent(this@SeatSelectionActivity, DashboardActivity::class.java)
                    startActivity(intent)
                }else{
                    Toast.makeText(
                        this@SeatSelectionActivity,
                        "Please select seats",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

        })
    }
}
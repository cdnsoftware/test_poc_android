package com.example.airplaneticketmanager.network

import com.example.airplaneticketmanager.models.Flight
import com.example.airplaneticketmanager.models.FlightListResponse
import com.example.airplaneticketmanager.models.FlightOptionsRequest
import com.example.airplaneticketmanager.models.LoginRequest
import com.example.airplaneticketmanager.models.LoginResponse
import com.example.airplaneticketmanager.models.SeatsAvailabilityRequestDTO
import com.example.airplaneticketmanager.models.SeatsAvailabilityResponse
import okhttp3.*
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @POST("/login")
    suspend fun login(
        @Body requestData: LoginRequest
    ): Response<LoginResponse>

    @GET("{id}")
    suspend fun fetchFlightList(
        @Path("id") id : String
//        @Body requestData: FlightOptionsRequest
    ): Response<FlightListResponse>

    @POST("/seatsAvailable")
    suspend fun seatsAvailable(
        @Body requestData: SeatsAvailabilityRequestDTO
    ): Response<SeatsAvailabilityResponse>
}


package com.example.airplaneticketmanager.models

data class FlightListResponse(
    var flights : ArrayList<Flight>,
    var responseMessage :String
)

data class Flight(
    var flightNumber : String = "",
    var departureTime :String = "",
    var price :String = ""
)
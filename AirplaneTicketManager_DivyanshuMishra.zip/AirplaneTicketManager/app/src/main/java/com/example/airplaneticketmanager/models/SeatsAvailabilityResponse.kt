package com.example.airplaneticketmanager.models

data class SeatsAvailabilityResponse(
    val seatsAvailable : String
)
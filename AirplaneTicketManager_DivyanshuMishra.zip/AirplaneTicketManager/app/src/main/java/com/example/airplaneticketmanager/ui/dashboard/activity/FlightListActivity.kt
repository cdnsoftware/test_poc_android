package com.example.airplaneticketmanager.ui.dashboard.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.airplaneticketmanager.BaseActivity
import com.example.airplaneticketmanager.Utils.Constants
import com.example.airplaneticketmanager.databinding.ActivityFlightListBinding
import com.example.airplaneticketmanager.models.Flight
import com.example.airplaneticketmanager.models.SeatsAvailabilityRequestDTO
import com.example.airplaneticketmanager.ui.dashboard.adapter.FlightListAdapter
import com.example.airplaneticketmanager.ui.dashboard.viewmodel.FetchFlightOptionsViewModel
import com.example.airplaneticketmanager.ui.dashboard.viewmodel.SeatAvailabilityViewModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.gsp.android.utils.ProgressBarHelper
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class FlightListActivity : BaseActivity() {

    lateinit var binding: ActivityFlightListBinding
    private val viewModel : SeatAvailabilityViewModel by viewModels()
    var TAG = javaClass.simpleName

    var from = ""
    var to = ""
    var date = ""
    var travellers = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFlightListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initView()
        apiResponse()
    }

    fun initView() {

        //getting intent data
        from = intent.getStringExtra(Constants.from).toString()
        to = intent.getStringExtra(Constants.to).toString()
        date = intent.getStringExtra(Constants.date).toString()
        travellers = intent.getStringExtra(Constants.travellers).toString()

        //fetching flight options list
        var flightOptionsList: ArrayList<Flight> = arrayListOf()
        val jsonStringData = intent.getStringExtra(Constants.flight_options_data).toString()
        if (!jsonStringData.isNullOrEmpty()) {
            val listType = object : TypeToken<ArrayList<Flight>>() {}.type
            // Convert the JSON string back to ArrayList
            flightOptionsList = Gson().fromJson(jsonStringData, listType)
        }
        val flightOptionsListSorted: ArrayList<Flight> = arrayListOf()
        for (flight in flightOptionsList) {
            if (flight.price.toDouble()<500.00){
                flightOptionsListSorted.add(flight)
            }
        }
        binding.backIcon.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        //setting view data
        binding.fromSn.text = from.subSequence(0, 3)
        binding.fromFn.text = from
        binding.toSn.text = to.subSequence(0, 3)
        binding.toFn.text = to
        binding.title.text = flightOptionsListSorted.size.toString() + " Flights Found"

        if (flightOptionsListSorted.isNotEmpty()) {
            val adapter = FlightListAdapter(flightOptionsListSorted, from, to, this)
            binding.rvFlightList.layoutManager = LinearLayoutManager(this)
            binding.rvFlightList.adapter = adapter
        }
    }

    fun fetchSeatAvailability(date: String, time: String, flightNumber: String) {
        val request = SeatsAvailabilityRequestDTO(date, time, flightNumber)

        //api calling for seat availability
//        viewModel.getSeatAvailability(request)

        //mock transaction of activity
        val intent = Intent(this, SeatSelectionActivity::class.java)
        intent.putExtra(Constants.travellers, travellers)
        startActivity(intent)
    }

    fun apiResponse() {
        // Observe success response
        viewModel.success.observe(this) { response ->
            Handler(Looper.getMainLooper()).postDelayed({
                ProgressBarHelper.hide()
            }, 2000)
            response?.let {
                // Handling success
                val intent = Intent(this, SeatSelectionActivity::class.java)
                startActivity(intent)
            }
        }

        // Observe error response
        viewModel.error.observe(this) { errorMessage ->
            Handler(Looper.getMainLooper()).postDelayed({
                ProgressBarHelper.hide()
            }, 2000)
            errorMessage?.let {
                // Handling error
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        }
    }
}
package com.example.airplaneticketmanager.models

data class FlightOptionsRequest(
    val from :String,
    val to : String,
    val date : String,
    val travellers : String,
)
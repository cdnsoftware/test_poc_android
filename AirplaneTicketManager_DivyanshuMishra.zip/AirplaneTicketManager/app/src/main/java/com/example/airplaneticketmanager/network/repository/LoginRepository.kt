package com.example.airplaneticketmanager.network.repository

import android.util.Log
import com.example.airplaneticketmanager.models.LoginRequest
import com.example.airplaneticketmanager.models.LoginResponse
import com.example.airplaneticketmanager.network.ApiService
import com.gsp.android.utils.LogUtil
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LoginRepository @Inject constructor(
    private val apiService: ApiService
) {
    val TAG = javaClass.simpleName
    suspend fun login(requestData: LoginRequest): LoginResponse? {
        return try {
            val response = apiService.login(requestData)
            if (response.isSuccessful) {
                response.body()
            } else {
                LogUtil.e(TAG, "login: "+ response.message())
                null
            }
        } catch (e: Exception) {
            // Handle exceptions
            e.printStackTrace()
            null
        }
    }
}

package com.example.airplaneticketmanager.models

data class SeatsAvailabilityRequestDTO(
    var date : String,
    var time : String,
    var flightNumer : String
)
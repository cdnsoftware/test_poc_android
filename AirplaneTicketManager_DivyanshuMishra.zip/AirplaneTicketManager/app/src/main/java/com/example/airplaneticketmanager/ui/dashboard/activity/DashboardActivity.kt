package com.example.airplaneticketmanager.ui.dashboard.activity

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.example.airplaneticketmanager.BaseActivity
import com.example.airplaneticketmanager.R
import com.example.airplaneticketmanager.Utils.Constants
import com.example.airplaneticketmanager.databinding.ActivityDashboardBinding
import com.example.airplaneticketmanager.models.Flight
import com.example.airplaneticketmanager.models.FlightOptionsRequest
import com.example.airplaneticketmanager.ui.dashboard.viewmodel.FetchFlightOptionsViewModel
import com.google.gson.Gson
import com.gsp.android.utils.ProgressBarHelper
import dagger.hilt.android.AndroidEntryPoint
import java.util.Calendar

@AndroidEntryPoint
class DashboardActivity : BaseActivity() {

    lateinit var binding: ActivityDashboardBinding
    var userName = ""
    private val fetchFlightOptionsViewModel: FetchFlightOptionsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        apiResponse()
        initView()
    }

    fun initView() {
        userName = intent.getStringExtra(Constants.username).toString()
        binding.tvName.text = ContextCompat.getString(this, R.string.welcome) + " " + userName + ","

        binding.etFrom.text.toString()

        binding.btnSubmit.setOnClickListener {
            if (binding.etFrom.text.toString().isBlank()) {
                Toast.makeText(this, "Please enter from location", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (binding.etTo.text.toString().isBlank()) {
                Toast.makeText(this, "Please enter to location", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (binding.departure.text.toString().isBlank()) {
                Toast.makeText(this, "Please select departure date", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (binding.etTravellers.text.toString().isBlank()) {
                Toast.makeText(this, "Please enter number of travellers", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (binding.etFrom.text.toString().length < 3) {
                Toast.makeText(this, "Please enter valid from address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (binding.etTo.text.toString().length < 3) {
                Toast.makeText(this, "Please enter valid to address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            ProgressBarHelper.show(this)
            val request = FlightOptionsRequest(
                binding.etFrom.text.toString(),
                binding.etTo.text.toString(),
                binding.departure.text.toString(),
                binding.etTravellers.text.toString()
            )

//          fetch flight options api call
            fetchFlightOptionsViewModel.fetchFlightOptions(request)
        }

        binding.departure.setOnClickListener {
            showDatePickerDialog()
        }
    }

    // Function to show DatePickerDialog
    private fun showDatePickerDialog() {

        // Get the current date
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        //max date
        calendar.add(Calendar.HOUR_OF_DAY, 48)
        val maxDate = calendar.timeInMillis

        val datePickerDialog = DatePickerDialog(
            this, R.style.CustomDatePickerDialog,
            { _, selectedYear, selectedMonth, selectedDay ->
                // DatePickerDialog returns month in 0-indexed format, so we add 1 to the month
                val selectedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                binding.departure.text = selectedDate
            }, year, month, day
        )

        datePickerDialog.datePicker.minDate = System.currentTimeMillis()
        datePickerDialog.datePicker.maxDate = maxDate

        datePickerDialog.show()
    }

    fun apiResponse() {
        // Observe success response
        fetchFlightOptionsViewModel.success.observe(this) { response ->
            ProgressBarHelper.hide()
            response?.let {
                ProgressBarHelper.hide()
                val intent = Intent(this, FlightListActivity::class.java)
                intent.putExtra(Constants.from, binding.etFrom.text.toString())
                intent.putExtra(Constants.to, binding.etTo.text.toString())
                intent.putExtra(Constants.flight_options_data, Gson().toJson(it.flights))
                intent.putExtra(Constants.date, binding.departure.text.toString())
                intent.putExtra(Constants.travellers, binding.etTravellers.text.toString())
                startActivity(intent)
            }
        }

        // Observe error response
        fetchFlightOptionsViewModel.error.observe(this) { errorMessage ->
            Handler(Looper.getMainLooper()).postDelayed({
                ProgressBarHelper.hide()
            }, 2000)
            errorMessage?.let {
                // Handling error
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        }
    }
}
package com.example.airplaneticketmanager.network.repository

import android.util.Log
import com.example.airplaneticketmanager.models.SeatsAvailabilityRequestDTO
import com.example.airplaneticketmanager.models.SeatsAvailabilityResponse
import com.example.airplaneticketmanager.network.ApiService
import com.gsp.android.utils.LogUtil
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SeatAvailablityRepository @Inject constructor(
    private val apiService: ApiService
) {

    val TAG = javaClass.simpleName
    suspend fun seatsAvailable(requestData: SeatsAvailabilityRequestDTO): SeatsAvailabilityResponse? {
        return try {
            val response = apiService.seatsAvailable(requestData)
            if (response.isSuccessful) {
                response.body()
            } else {
                LogUtil.e(TAG, "login: "+ response.message())
                null
            }
        } catch (e: Exception) {
            // Handle exceptions
            e.printStackTrace()
            null
        }
    }
}

package com.example.airplaneticketmanager.network.repository

import android.util.Log
import com.example.airplaneticketmanager.models.Flight
import com.example.airplaneticketmanager.models.FlightListResponse
import com.example.airplaneticketmanager.models.FlightOptionsRequest
import com.example.airplaneticketmanager.models.LoginRequest
import com.example.airplaneticketmanager.network.ApiService
import com.gsp.android.utils.LogUtil
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FetchFlightListRepository @Inject constructor(
    private val apiService: ApiService
) {
    val TAG = javaClass.simpleName
    suspend fun fetchFlightOptions(requestData: FlightOptionsRequest, id : String): FlightListResponse? {
        return try {
            val response = apiService.fetchFlightList(id)
            if (response.isSuccessful) {
                response.body()
            } else {
                LogUtil.e(TAG, "login: "+ response.message())
                null
            }
        } catch (e: Exception) {
            // Handle exceptions
            e.printStackTrace()
            null
        }
    }
}

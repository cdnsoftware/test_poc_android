package com.example.airplaneticketmanager.models

data class LoginRequest(
    var username : String,
    var password : String
)
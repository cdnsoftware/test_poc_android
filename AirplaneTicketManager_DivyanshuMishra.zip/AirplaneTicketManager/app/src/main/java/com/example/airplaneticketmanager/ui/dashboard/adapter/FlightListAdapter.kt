package com.example.airplaneticketmanager.ui.dashboard.adapter

import android.app.Activity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.airplaneticketmanager.R
import com.example.airplaneticketmanager.models.Flight
import com.example.airplaneticketmanager.ui.dashboard.activity.FlightListActivity
import com.example.airplaneticketmanager.ui.dashboard.activity.SeatSelectionActivity
import com.gsp.android.utils.ProgressBarHelper

class FlightListAdapter(
    private var itemList: ArrayList<Flight>,
    var from: String,
    var to: String,
    val activity: Activity
) : RecyclerView.Adapter<FlightListAdapter.MyViewHolder>() {

    // ViewHolder represents each item in the RecyclerView
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fromSn: TextView = itemView.findViewById(R.id.tv_from_sn)
        val fromFn: TextView = itemView.findViewById(R.id.tv_from_fn)
        val toSn: TextView = itemView.findViewById(R.id.tv_to_sn)
        val toFn: TextView = itemView.findViewById(R.id.tv_to_fn)
        val date: TextView = itemView.findViewById(R.id.date)
        val time: TextView = itemView.findViewById(R.id.time)
        val price: TextView = itemView.findViewById(R.id.price)
        val flightNumber: TextView = itemView.findViewById(R.id.tv_flight_name)
        val root: CardView = itemView.findViewById(R.id.root)
    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_flight_list, parent, false)
        return MyViewHolder(itemView)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.flightNumber.text = itemList[position].flightNumber
        holder.time.text = itemList[position].departureTime.subSequence(11,19)
        holder.price.text = "$" + itemList[position].price

        holder.fromFn.text = from
        holder.fromSn.text = from.subSequence(0, 3)
        holder.toFn.text = to
        holder.toSn.text = to.subSequence(0, 3)
        holder.date.text = itemList[position].departureTime.subSequence(0, 10)

        holder.root.setOnClickListener {
            ProgressBarHelper.show(activity)
            Handler(Looper.getMainLooper()).postDelayed({
                ProgressBarHelper.hide()
                (activity as FlightListActivity).fetchSeatAvailability(itemList[position].departureTime.subSequence(0,10).toString(), itemList[position].departureTime, itemList[position].flightNumber)
            }, 1000)
        }
    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount() = itemList.size
}
package com.hackerrank.flightbooking



/****responce & responce status code for handling***/
data class ApiResponse(val status: Int, val body: String?)
data class FlightResponse(
    val flights: ArrayList<Flight>,
    val responseMessage: String
)

data class Flight(val flightNumber: String, val departureTime: String, val price: Double)

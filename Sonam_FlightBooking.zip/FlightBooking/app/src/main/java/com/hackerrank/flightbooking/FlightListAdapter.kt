package com.hackerrank.flightbooking

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class FlightListAdapter(
    private val flightList: ArrayList<Flight>,
    private val flighSeatsCallBack: FlighSeatsCallBack
) : RecyclerView.Adapter<FlightListAdapter.FlightViewHolder>() {
    private var filteredFlights = flightList.toMutableList()

    inner class FlightViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvFlightNumber: TextView = itemView.findViewById(R.id.tvFlightNumber)
        val tvDepartureTime: TextView = itemView.findViewById(R.id.tvDepartureTime)
        val tvArrivalTime: TextView = itemView.findViewById(R.id.tvArrivalTime)
        val cv: CardView = itemView.findViewById(R.id.cv)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FlightViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.flight_list_item_view, parent, false) // Replace with your layout filename
        return FlightViewHolder(view)
    }

    override fun onBindViewHolder(holder: FlightViewHolder, position: Int) {
        val flight = filteredFlights[position]
        holder.tvFlightNumber.text = flight.flightNumber
        holder.tvDepartureTime.text =flight.departureTime
        holder.tvArrivalTime.text =  ""+flight.price

        holder.cv.setOnClickListener {
            /***Handle button click for flight details***/
            flighSeatsCallBack.getFlightSeatAvailablity(flight)
        }
    }

    override fun getItemCount(): Int {
        return filteredFlights.size
    }

    /****Filter function to search through the flight list****/
    fun filter(query: String) {
        filteredFlights.clear()

        if (query.isEmpty()) {
            // If query is empty, reset the filtered list to show all flights
            filteredFlights.addAll(flightList)
        } else {
            // Convert query to lowercase for case-insensitive comparison
            val lowerCaseQuery = query.lowercase()

            // Filter the flights based on the query
            filteredFlights.addAll(flightList.filter {
                it.flightNumber.lowercase().contains(lowerCaseQuery)
//                        || it.departureTime.lowercase().contains(lowerCaseQuery) || it.price.toString().contains(lowerCaseQuery)
            })
        }

        // Notify the adapter that the data has changed, so the list is updated
        notifyDataSetChanged()
    }

    interface FlighSeatsCallBack{
        fun getFlightSeatAvailablity(flight: Flight)
    }

}

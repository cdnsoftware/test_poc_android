package com.hackerrank.flightbooking.flighviewmodels

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.hackerrank.flightbooking.ApiResponse
import com.hackerrank.flightbooking.Flight
import com.hackerrank.flightbooking.FlightResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
class FlightsViewModel (application: Application): /*ViewModel()*/ AndroidViewModel(application) {

    private val _flightList = MutableLiveData<List<Flight>>()
    val flightList: LiveData<List<Flight>> get() = _flightList

    private val _isLoading = MutableLiveData<Boolean>()
    private val _isSeatAvailable = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading
    val isSeatAvailable: LiveData<Boolean> get() = _isSeatAvailable
    private val _isInternetAvailable = MutableLiveData<Boolean>()
    val isInternetAvailable: LiveData<Boolean> get() = _isInternetAvailable

    fun fetchFlightOptions(urlString: String) {
        if (isInternetConnected()){
            _isLoading.value = true
            viewModelScope.launch {
                val response = fetchFlightOptionsFromApi(urlString)
                _isLoading.value = false

                if (response.status == 200) {
                    getResponce(response.status,response.body)

                } else {
                    // Handle errors based on response.status
                }
            }
        }else{
            _isInternetAvailable.value = false
        }

    }

    fun filterFlights(flights: List<Flight>): List<Flight> {
        try {
            val currentDateTime = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                LocalDateTime.now()
            } else {
                TODO("VERSION.SDK_INT < O")
            }
            val futureDateTime = currentDateTime.plusHours(48)

            return flights.filter {
                val departureDateTime = LocalDateTime.parse(it.departureTime, DateTimeFormatter.ISO_DATE_TIME)
                it.price < 500 && departureDateTime.isAfter(currentDateTime) && departureDateTime.isBefore(futureDateTime)
            }
        } catch (e: Exception) {
           return flights
        }
    }


    /********Flight list Responce handling*********/
    private fun getResponce(responseCode: Int, responseBody: String?) {
        try {
            when (responseCode) {
                200 -> {
                    /****Handle success****/
                    println("Success: ${responseBody}")
                    val flightResponse = Gson().fromJson(responseBody, FlightResponse::class.java)
                    _flightList.value = filterFlights(flightResponse.flights)

                }

                400 -> {
                    /****Handle bad request****/
                    println("Bad Request: ${responseBody}")
                }

                500 -> {
                    /****Handle server error****/
                    println("Server Error: ${responseBody}")
                }

                else -> {
                    /****Handle other status codes****/
                    println("Error ${responseCode}: ${responseBody}")
                }
            }
        } catch (e: Exception) {
            /****Handle any uncaught exceptions****/
            println("Exception: ${e.localizedMessage}")
        }

    }
    /*******Fetch flight's from server using coroutines****/
    private suspend fun fetchFlightOptionsFromApi(urlString: String): ApiResponse {
        return withContext(Dispatchers.IO) {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(urlString)
                connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 15000
                connection.readTimeout = 15000

                val responseCode = connection.responseCode
                val responseBody = if (responseCode == 200) {
                    BufferedReader(InputStreamReader(connection.inputStream)).use { it.readText() }
                } else {
                    BufferedReader(InputStreamReader(connection.errorStream)).use { it.readText() }
                }

                ApiResponse(responseCode, responseBody)
            } catch (e: Exception) {
                ApiResponse(500, "Error: ${e.localizedMessage}")
            } finally {
                connection?.disconnect()
            }
        }
    }

    /****functions for fetchSeatAvailability if needed*****/
    fun fetchSeatAvailability(urlString: String) {
        if (isInternetConnected()){
        _isLoading.value = true
        viewModelScope.launch {
            val isSeatAvailable = fetchSeatAvailabilityFromApi(urlString)
            _isSeatAvailable.value=isSeatAvailable
            _isLoading.value = false
        }
    }else{
        _isInternetAvailable.value = false
    }
    }

    suspend fun fetchSeatAvailabilityFromApi(flightNumber: String): Boolean {
        return withContext(Dispatchers.IO) {
            var connection: HttpURLConnection? = null
            try {
                // Construct the URL for the API endpoint
                val url =
                    URL("https://your-api-url.com/seatAvailability?flightNumber=$flightNumber")

                // Open a connection to the URL
                connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET" // Since we are fetching data, we use GET

                // Set timeouts
                connection.connectTimeout = 15000
                connection.readTimeout = 15000

                // Get the response code
                val responseCode = connection.responseCode

                // Handle response
                if (responseCode == 200) {
                    // Read the response from the input stream
                    BufferedReader(InputStreamReader(connection.inputStream)).use { reader ->
                        val response = reader.readText()

                        // Simulate checking seat availability from response (assuming the response contains a boolean)
                        return@withContext response.trim() == "true" // Simulate response parsing
                    }
                } else {
                    // If response is not 200, we assume no seat availability
                    return@withContext false
                }
            } catch (e: Exception) {
                // Handle exceptions such as network issues, timeouts, etc.
                println("Error fetching seat availability: ${e.localizedMessage}")
                return@withContext false
            } finally {
                // Ensure connection is closed
                connection?.disconnect()
            }
        }
    }

    /***** Check if internet is available *****/
    private fun isInternetConnected(): Boolean {
        val connectivityManager = getApplication<Application>()
            .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = connectivityManager.activeNetwork ?: return false
            val activeNetwork = connectivityManager.getNetworkCapabilities(network) ?: return false

            return when {
                activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                activeNetwork.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }
        } else {
            val networkInfo = connectivityManager.activeNetworkInfo
            return networkInfo?.isConnectedOrConnecting == true
        }
    }
}

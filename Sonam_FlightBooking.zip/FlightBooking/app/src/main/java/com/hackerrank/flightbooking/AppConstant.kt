package com.hackerrank.flightbooking

object AppConstant {
    /****Base url for fetah data from server****/
    val BASEURL="https://run.mocky.io/"
//https://run.mocky.io/v3/f3cea6fb-c348-4651-a882-3443d555ccd8

    /****END url ****/
    val fetchFlightList="v3/f3cea6fb-c348-4651-a882-3443d555ccd8"
    val searchFlightSeatList="v3/f3cea6fb-c348-4651-a882-3443d555ccd8"

    var FLIGHTDATA="flightdata"

}
package com.hackerrank.flightbooking

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import com.google.gson.Gson
import com.hackerrank.flightbooking.databinding.ActivitySeatAvailabilityBinding
import com.hackerrank.flightbooking.flighviewmodels.FlightsViewModel
import dev.jahidhasanco.seatbookview.SeatClickListener

class SeatAvailabilityActivity : AppCompatActivity(), View.OnClickListener {
    private val viewModel: FlightsViewModel by viewModels()
    private lateinit var binding: ActivitySeatAvailabilityBinding
    private var seatNum = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySeatAvailabilityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (intent.hasExtra(AppConstant.FLIGHTDATA)) {
            val flightResponse =
                Gson().fromJson(intent.getStringExtra(AppConstant.FLIGHTDATA), Flight::class.java)
            binding.etFlightNumber.setText(flightResponse.flightNumber)
        }


        showSeatInputDialog(this)

        /*****Observe the loading state****/
        viewModel.isLoading.observe(this, Observer { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        })

        // Observe the flight list
        viewModel.isSeatAvailable.observe(this, Observer { flights ->
            /*****Handle flight list update (if needed)***/
            if (flights) {
                binding.textViewSeats.text =
                    "Seats are available for flight" + " " + binding.etFlightNumber.text.toString()
            } else {
                binding.textViewSeats.text =
                    "No seats available for flight" + " " + binding.etFlightNumber.text.toString()
            }
        })


    }

    fun initView() {

        var seats =
            ("/R___R" + "/_____" + "/AA_AA" + "/AA_AR" + "/AA_AA" + "/RR_AA" + "/AA_AR" + "/AR_AA" + "/AA_AA" + "/AAAAA")

        var title = listOf(
            "/",
            "I1",
            "",
            "",
            "",
            "E5",
            "/",
            "",
            "",
            "",
            "",
            "",
            "/",
            "A1",
            "A2",
            "",
            "A3",
            "A4",
            "/",
            "B1",
            "B2",
            "",
            "B3",
            "B4",
            "/",
            "C1",
            "C2",
            "",
            "C3",
            "C4",
            "/",
            "D1",
            "D2",
            "",
            "D3",
            "D4",
            "/",
            "E1",
            "E2",
            "",
            "E3",
            "E4",
            "/",
            "F1",
            "F2",
            "",
            "F3",
            "F4",
            "/",
            "G1",
            "G2",
            "",
            "G3",
            "G4",
            "/",
            "H1",
            "H2",
            "H3",
            "H4",
            "H5"
        )

        binding.seatBookView.setSeatsLayoutString(seats).isCustomTitle(true).setCustomTitle(title)
            .setSeatLayoutPadding(2).setSelectSeatLimit(seatNum)
//            .setSelectSeatLimit(travellers.toInt())
            .setSeatSizeBySeatsColumnAndLayoutWidth(5, -1)

        binding.seatBookView.setSeatClickListener(object : SeatClickListener {
            override fun onAvailableSeatClick(selectedIdList: List<Int>, view: View) {
                binding.seatBookView.setAvailableSeatsTextColor(
                    ContextCompat.getColor(
                        this@SeatAvailabilityActivity,
                        R.color.white
                    )
                )
            }

            override fun onBookedSeatClick(view: View) {
            }

            override fun onReservedSeatClick(view: View) {
                Toast.makeText(
                    this@SeatAvailabilityActivity,
                    (view as TextView).text.toString() + " seat is already reserved.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })

        binding.seatBookView.show()

    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btnConfirm -> {
                val selectedSeatCount = binding.seatBookView.getSelectedIdList().size

                if (selectedSeatCount!=seatNum){
                    Toast.makeText(this,"Please select seat",Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this,"Your booking is confirm",Toast.LENGTH_SHORT).show()
                    this.finish()
                }

            }
            R.id.btnCheckAvailability -> {
                viewModel.fetchSeatAvailability(AppConstant.BASEURL + AppConstant.searchFlightSeatList)
            }
        }
    }

    fun showSeatInputDialog(context: Context) {
        // Inflate the custom layout for the dialog
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_seat_input, null)
        val editTextSeat = dialogView.findViewById<EditText>(R.id.editTextSeat)

        // Create the AlertDialog
        val dialog = AlertDialog.Builder(context)
            .setTitle("Select Seat")
            .setView(dialogView)
            .setPositiveButton("OK", null) // Set null for the listener initially
            .create()

        // Set a listener for the positive button
        dialog.setOnShowListener {
            val button = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            button.setOnClickListener {
                val seatNumber = editTextSeat.text.toString().trim() // Trim to avoid spaces

                if (seatNumber.isEmpty()) {
                    Toast.makeText(context, "Please enter a seat number", Toast.LENGTH_SHORT).show()
                } else {
                    handleSeatSelection(seatNumber)
                    dialog.dismiss() // Dismiss the dialog if input is valid
                }
            }
        }

        dialog.show() // Show the dialog
    }

    private fun handleSeatSelection(seatNumber: String) {
        seatNum = seatNumber.toInt()
        binding.btnConfirm.visibility=View.VISIBLE
        initView()
        // Handle the seat selection (e.g., save it to a variable or database)
        // For example, you can show a Toast message
        Toast.makeText(this, "You selected seat: $seatNumber", Toast.LENGTH_SHORT).show()
    }
}

package com.hackerrank.flightbooking

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Handler
import android.os.Looper
import com.hackerrank.flightbooking.databinding.ActvityFlightSplashScreenBinding



class FlightSplashScreenActivity: AppCompatActivity() {
    private lateinit var binding: ActvityFlightSplashScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActvityFlightSplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, FlightListActivity::class.java))
            finish() // Close the splash screen activity
        }, 2000) // Display for 3 seconds
    }
}
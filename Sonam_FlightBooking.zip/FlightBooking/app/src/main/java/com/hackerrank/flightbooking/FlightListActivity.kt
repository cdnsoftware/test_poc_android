package com.hackerrank.flightbooking

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.hackerrank.flightbooking.databinding.ActivityFlightListBinding
import com.hackerrank.flightbooking.flighviewmodels.FlightsViewModel

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.widget.EditText
class FlightListActivity : AppCompatActivity(), FlightListAdapter.FlighSeatsCallBack {
    private lateinit var flightListAdapter: FlightListAdapter
    private var flightList = ArrayList<Flight>()

    private lateinit var binding: ActivityFlightListBinding
    private val viewModel: FlightsViewModel by viewModels()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFlightListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel.fetchFlightOptions(AppConstant.BASEURL + AppConstant.fetchFlightList)

        viewModel.isInternetAvailable.observe(this) { isConnected ->
            if (!isConnected) {
                // Show a message or alert to the user about the lack of internet connection
                Toast.makeText(this, "Please check internet connection", Toast.LENGTH_SHORT).show()
            }
        }


        /*****Observe the loading state****/
        viewModel.isLoading.observe(this, Observer { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        })

        // Observe the flight list
        viewModel.flightList.observe(this, Observer { flights ->
            /*****Handle flight list update (if needed)***/
            val flightArrayList = ArrayList(flights)
            flightList = flightArrayList
            setFlightData()
        })


        binding.recyclerView.layoutManager = LinearLayoutManager(this)


        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                flightListAdapter.filter(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {}
        })


    }

    private fun setFlightData() {
        flightListAdapter = FlightListAdapter(flightList, this)
        binding.recyclerView.adapter = flightListAdapter
    }


    override fun getFlightSeatAvailablity(flight: Flight) {
        var intent = Intent(this, SeatAvailabilityActivity::class.java)
        intent.putExtra(AppConstant.FLIGHTDATA, Gson().toJson(flight))
        startActivity(intent)
    }





}